﻿using ClosedXML.Excel;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.ServiceProcess;
using System.Timers;

namespace SoEmail
{
    public partial class Service1 : ServiceBase
    {
        string strLogPath = ConfigurationSettings.AppSettings["LogPath"];
        Timer _timer = new Timer();
        string strLog = "";
        private string strfname;
        private string Path;
        string path = ""; 
        public Service1()
        {

            InitializeComponent();
            _timer.Interval = Convert.ToDouble(ConfigurationSettings.AppSettings["TimerInterval"].ToString());

            //enabling the timer
            _timer.Enabled = true;

            //handle Elapsed event
            _timer.Elapsed += new ElapsedEventHandler(_timer_Elapsed);


        }

        private void _timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            _timer.Stop();

            try
            {
                string TimerDuration = ConfigurationSettings.AppSettings["TimerDuration"].ToString();
                string strCurrnetTime = System.DateTime.Now.Hour.ToString() + ":" + System.DateTime.Now.Minute.ToString();


                if (TimerDuration.Split(',').Contains(strCurrnetTime))
                {
                    strLog = DateTime.Now.ToString("hh:mm:ss tt") + "Hittttttted Time taken service " + strCurrnetTime;
                    if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                        using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                            objWritter.WriteLine(strLog);
                    else
                        using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                            objWritter.WriteLine(strLog);
                    CreditControlMail();
                }
                else
                {
                    strLog = DateTime.Now.ToString("hh:mm:ss tt") + " Time not Hitting service " + strCurrnetTime;
                    if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                        using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                            objWritter.WriteLine(strLog);
                    else
                        using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_So_LOG.txt"))
                            objWritter.WriteLine(strLog);
                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                _timer.Start();
            }
        }

         
        private string converttoexcel( string so_id,DataTable dt1, DataTable dt2=null)
        {
            XLWorkbook wb = new XLWorkbook();
            var ws1 = wb.Worksheets.Add(dt1, "Sheet1");
            ws1.Name = "Available Credit";
            if (dt2 != null) // not sure if this check is needed, remove it and check if it works correctly
            {
                var ws2 = wb.Worksheets.Add(dt2, "Sheet2");
                ws2.Name = "Credit Trend";
            }
            DateTime localDate = DateTime.Now; //set filename id and datetime
            strfname = so_id + " " + DateTime.Now.ToString().RemoveSpecialCharacters();
            Path= @"D:\\CreditReport\\EXCEL\" + strfname + ".xlsx";
            wb.SaveAs(Path);
            return strfname;
 
        }


        private DataTable sp_Creditcontrol_date() {
            SqlTransaction tran = null;
            SqlCommand _command = new SqlCommand();
             
            SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["ConStr"].ToString());

            if (con.State.ToString() != "Open")
                con.Open();
            _command.Connection = con;
            tran = con.BeginTransaction();
            DataTable dtP = new DataTable();
            try
            {
                _command.Transaction = tran;
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandTimeout = 500000;
                _command.CommandText = "sp_Creditcontrol_date";

                _command.Parameters.Clear();

                using (SqlDataAdapter sda = new SqlDataAdapter(_command))
                {
                    sda.Fill(dtP);
                    tran.Commit();
                    con.Close();
                }
            }
            catch (SqlException ex)
            {
                con.Close();
            }
            return dtP;
        }

        private DataTable ReturndatatableSQL(string strQry)
        {
            DataTable dt = new DataTable();
             
            try
            {
                    string _strConstr = ConfigurationSettings.AppSettings["ConStr"].ToString();

                    try
                    {
                        using (SqlConnection conn = new SqlConnection(_strConstr))
                        {
                            try
                            {
                                conn.Open();
                                SqlDataAdapter da = new SqlDataAdapter(strQry, conn);
                                da.Fill(dt); conn.Close();
                            }
                            catch (SqlException ex)
                            { if (conn.State == ConnectionState.Open) conn.Close(); }
                        }
                    }
                    catch (Exception ex) { }
                
            }
            catch (Exception ex1) { }
            return dt;
        }
        public void CreditControlMail()
        {
            // call Siva SP to get dt1
             
            DataTable dtuser = new DataTable();
            DataTable dtAgentDetails = new DataTable();
            DataTable dtcredit = new DataTable();
            DataTable dtCreditOutcome = new DataTable();
            dtcredit = sp_Creditcontrol_date();
            string strQry = "";
            strQry = "select  emp_id, emP_group, email  from  Employee_Detail_Master ";
            dtuser = ReturndatatableSQL(strQry);
            if (dtuser.Rows.Count > 0)
            {
                for (int i = 0; i < dtuser.Rows.Count; i++)
                {
                    if (dtuser.Rows[i]["emp_group"].ToString().Trim() == "SO")
                    {
                        strQry = "select * from VW_CREDIT_CONTROL where   so_id='";
                        strQry += dtuser.Rows[i]["emp_id"].ToString().Trim() + "'";
                    }
                    else if (dtuser.Rows[i]["emp_group"].ToString().Trim() == "SH")
                    {
                        strQry = "select * from VW_CREDIT_CONTROL where   sales_head_id='";
                        strQry += dtuser.Rows[i]["emp_id"].ToString().Trim() + "'";
                    }
                    else
                    {
                        strQry = "select * from VW_CREDIT_CONTROL";

                    }
                    dtAgentDetails = ReturndatatableSQL(strQry);
                    if (dtAgentDetails.Rows.Count > 0)
                    {
                        //remove the unwanted columns
                        dtAgentDetails.Columns.Remove("SO_MOBILE");
                        dtAgentDetails.Columns.Remove("SO_ID");
                        dtAgentDetails.Columns.Remove("SO_EMAIL");
                        dtAgentDetails.Columns.Remove("SALES_HEAD_ID");
                        dtAgentDetails.Columns.Remove("SALES_HEAD_EMAIL");
                        dtAgentDetails.Columns.Remove("SALES_HEAD_MOBILE");
                        dtAgentDetails.Columns.Remove("Active_Status");
                        dtAgentDetails.Columns.Remove("datefifference");
                    }

                    string expression;
                    DataRow[] foundRows;
                    if (dtuser.Rows[i]["emp_group"].ToString().Trim() == "SO")
                    {
                        expression = "SalesOffCode = '" + dtuser.Rows[i]["emp_id"].ToString().Trim()+"'";
                        foundRows = dtcredit.Select(expression);
                        if (foundRows.Length > 0)
                        {
                            dtCreditOutcome = foundRows.CopyToDataTable();
                        }
                    }
                    else if (dtuser.Rows[i]["emp_group"].ToString().Trim() == "SH")
                    {
                        expression = "SalesHeadCode = '" + dtuser.Rows[i]["emp_id"].ToString().Trim()+"'";
                        foundRows = dtcredit.Select(expression);
                        if (foundRows.Length > 0)
                        {
                            dtCreditOutcome = foundRows.CopyToDataTable();
                        }
                    }
                    else
                    {
                        dtCreditOutcome = dtcredit;
                    }


                     
                    //convert to excel 
                    string filename = converttoexcel(dtuser.Rows[i]["emp_id"].ToString().Trim(), dtAgentDetails,dtCreditOutcome);
                    //send mail to dtuser.Rows[i]["email"];
                    bool Send = false;
                    Send = SendEmail(dtuser.Rows[i]["email"].ToString().Trim(), filename);

                    if (Send == true)
                    {
                        if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmail_Logs.txt"))
                            using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmail_Logs.txt"))
                                objWritter.WriteLine("Message : " + DateTime.Now.ToString("hh:mm:ss tt") + " " + "Email" + " " + dtuser.Rows[i]["email"].ToString().Trim() + "  To filename: " + filename + " Mail send successfully ");
                        else
                            using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmail_Logs.txt"))
                                objWritter.WriteLine("Message : " + DateTime.Now.ToString("hh:mm:ss tt") + " " + "Email" + " " + dtuser.Rows[i]["email"].ToString().Trim() + "  To filename: " + filename + "  Mail send successfully ");
                    }
                    else
                    {
                        if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_Rss1timesFail_Logs.txt"))
                            using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmail_Logs_Fail.txt"))
                                objWritter.WriteLine("Message : " + DateTime.Now.ToString("hh:mm:ss tt") + " " + "Email" + " " + dtuser.Rows[i]["email"].ToString().Trim() + "  To filename : " + filename + "  Mail sending Faild ");
                        else
                            using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmail_Logs_Fail.txt"))
                                objWritter.WriteLine("Message : " + DateTime.Now.ToString("hh:mm:ss tt") + " " + "Email" + " " + dtuser.Rows[i]["email"].ToString().Trim() + "  To filename: " + filename + "  Mail sending Faild ");
                    }
                }
            }
        }


        bool SendEmail(string email, string FileName )
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.office365.com");
            mail.From = new MailAddress("notify@thehindutamil.co.in", "The Hindu Tamil");
            mail.To.Add(email);
           
            mail.Subject = "Circulation Credit Report and Credit control report";
            mail.Body = "Please find attached the details of circulation credit available for the agents in your region. Please take necessary action." + "Please contact Arthi/Sivabalan for any queries. ";
            System.Net.Mail.Attachment attachment;
             
            attachment = new System.Net.Mail.Attachment(Path);
            mail.Attachments.Add(attachment);
            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("notify@thehindutamil.co.in", "Vjjgh+zJQnxCPzwg=pfuKQkoePPVbgUSgeCdDX59M18t");
            SmtpServer.EnableSsl = true;
            SmtpServer.Send(mail);
            return true;
        }

    protected override void OnStart(string[] args)
        {
            _timer.Start();
            strLogPath = ConfigurationSettings.AppSettings["LogPath"].ToString();

            if (!Directory.Exists(strLogPath))
                Directory.CreateDirectory(strLogPath);

            if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmail_LOG.txt"))
                using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmail_LOG.txt"))
                    objWritter.WriteLine(DateTime.Now.ToString("hh:mm:ss tt") + " _SoEmail_LOG  Service Started ....");
            else
                using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmail_LOG.txt"))
                    objWritter.WriteLine(DateTime.Now.ToString("hh:mm:ss tt") + " _SoEmail_LOG  Service Started ....");
        }

        protected override void OnStop()
        {
            _timer.Stop();

            if (!Directory.Exists(strLogPath))
                Directory.CreateDirectory(strLogPath);

            if (!File.Exists(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmailStop_LOG.txt"))
                using (StreamWriter objWritter = File.CreateText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmailStop_LOG.txt"))
                    objWritter.WriteLine(DateTime.Now.ToString("hh:mm:ss tt") + " _SoEmailStop_LOG  Service Stoped ....");
            else
                using (StreamWriter objWritter = File.AppendText(strLogPath + DateTime.Now.ToString("dd-MMM-yyyy") + "_SoEmailStop_LOG.txt"))
                    objWritter.WriteLine(DateTime.Now.ToString("hh:mm:ss tt") + "_SoEmailStop_LOG  Service Stoped ....");
        }
    }
}
